1. You need to update your email address with mine.
2. You need to setup 'less app secure' setting as on in order to execute the program: https://support.google.com/accounts/thread/22873505/this-browser-or-app-may-not-be-secure-error-when-trying-to-sign-in-with-google-on-desktop-apps?hl=en
3. Make sure chromedriver.exe used is compatible for your Google chrome version