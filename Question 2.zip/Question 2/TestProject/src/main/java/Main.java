import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver",".//chromedriver.exe");
        WebDriver driver =new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
        driver.manage().window().maximize();
        driver.get("http://jt-dev.azurewebsites.net/#/SignUp");
        driver.findElement(By.xpath("//span[contains(text(),'English')]"));
        driver.findElement(By.xpath("//div[@placeholder='Choose Language']")).click();
        driver.findElement(By.xpath("//div[contains(text(),'Dutch')]"));
        driver.findElement(By.id("name")).sendKeys("TestAzhar");
        driver.findElement(By.id("orgName")).sendKeys("TestAzhar");
        driver.findElement(By.id("singUpEmail")).sendKeys("azharshaikhqa@gmail.com");
        driver.findElement(By.xpath("//span[contains(text(),'I agree')]")).click();
        driver.findElement(By.xpath("//button[@type='submit']")).click();
        driver.get("https://mail.google.com/mail/u/0/#inbox");
        driver.findElement(By.xpath("//input[@type='email']")).sendKeys("traderqa");
        WebElement element=driver.findElement(By.xpath("//div[@class='VfPpkd-RLmnJb'][1]"));
        JavascriptExecutor js=(JavascriptExecutor)driver;
        js.executeScript("arguments[0].click();",element);
        driver.findElement(By.xpath("//input[@type='password']")).sendKeys("");
        element=driver.findElement(By.xpath("//div[@class='VfPpkd-RLmnJb'][1]"));
        js=(JavascriptExecutor)driver;
        js.executeScript("arguments[0].click();",element);
        driver.findElement(By.xpath("//div[@class='VfPpkd-RLmnJb'][1]")).click();
        driver.findElement(By.xpath("//span[@email='donotreply-dev@jabatalks.com']']"));
    }
}
