import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import java.time.Duration;


public class Main {

    public static WebDriver driver;

    public static boolean gmail_Data(String mail_id,String password){
        try {
            driver.get("https://accounts.google.com/signin/v2/identifier?continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&service=mail&sacu=1&rip=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin");
            driver.findElement(By.xpath("//input[@type='email']")).sendKeys(mail_id);
            WebElement element = driver.findElement(By.xpath("//div[@class='VfPpkd-RLmnJb'][1]"));
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].click();", element);
            driver.findElement(By.cssSelector("input[name='password']")).sendKeys(password);
            element = driver.findElement(By.xpath("//div[@class='VfPpkd-RLmnJb'][1]"));
            js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].click();", element);
            return driver.findElement(By.xpath("//span[@email='donotreply-dev@jabatalks.com']']")).isDisplayed();
        }
        catch(Exception e){
            return false;
        }

    }

    public static void fillData(String mail_id){
        driver.findElement(By.id("name")).sendKeys("TestD");
        driver.findElement(By.id("orgName")).sendKeys("TestD");

        driver.findElement(By.id("singUpEmail")).sendKeys(mail_id);
        driver.findElement(By.xpath("//span[contains(text(),'I agree')]")).click();
        driver.findElement(By.xpath("//button[@type='submit']")).click();

    }

    public static void main(String[] args) {
         String mail_id="mydum316@gmail.com";
         String password="Abcd@123";

        System.setProperty("webdriver.chrome.driver",".//chromedriver.exe");
        driver =new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
        driver.manage().window().maximize();

        driver.get("http://jt-dev.azurewebsites.net/#/SignUp");
        driver.findElement(By.xpath("//span[contains(text(),'English')]"));
        driver.findElement(By.xpath("//div[@placeholder='Choose Language']")).click();
        driver.findElement(By.xpath("//div[contains(text(),'Dutch')]"));

        fillData(mail_id);

        if(gmail_Data(mail_id,password)){
            System.out.println("Passed");
        }
        else{
            System.out.println("Failed");
        }

        driver.quit();

    }
}
